package com.radiohora.app;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.speech.tts.UtteranceProgressListener;
import androidx.annotation.Nullable;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;
import java.time.LocalTime;
import java.util.Locale;

public class RadioService extends MediaSessionService {
    private ExoPlayer player;
    private MediaSession session;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean pendingAnnouncement = false;
    private boolean speaking = false;
    private int lastSlot = -1;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable clock = new Runnable() {
        @Override public void run() {
            LocalTime now = LocalTime.now();
            int slot = now.getHour() * 4 + now.getMinute() / 15;
            if (now.getMinute() % 15 == 0 && slot != lastSlot) {
                lastSlot = slot;
                pendingAnnouncement = true;
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        player = new ExoPlayer.Builder(this).build();
        player.setRepeatMode(Player.REPEAT_MODE_ALL);
        player.addListener(new Player.Listener() {
            @Override public void onMediaItemTransition(@Nullable androidx.media3.common.MediaItem item, int reason) {
                if (pendingAnnouncement && item != null && ttsReady && !speaking) announceAtBoundary();
            }
        });
        session = new MediaSession.Builder(this, player).build();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("es", "ES"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
                if (ttsReady) {
                    // Android TTS does not guarantee a male voice. Prefer one when identifiable.
                    for (Voice voice : tts.getVoices()) {
                        if (voice.getLocale().getLanguage().equals("es") && voice.getName().toLowerCase(Locale.ROOT).contains("male")) {
                            tts.setVoice(voice); break;
                        }
                    }
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) {}
                        @Override public void onDone(String id) { handler.post(() -> { speaking = false; player.play(); }); }
                        @Override public void onError(String id) { handler.post(() -> { speaking = false; player.play(); }); }
                    });
                }
            }
        });
        handler.post(clock);
    }

    private void announceAtBoundary() {
        pendingAnnouncement = false;
        speaking = true;
        player.pause();
        LocalTime now = LocalTime.now();
        int h = now.getHour();
        int m = now.getMinute();
        String part = h < 12 ? "de la mañana" : (h < 19 ? "de la tarde" : "de la noche");
        int hour12 = h % 12 == 0 ? 12 : h % 12;
        String text = "Son las " + hour12 + " y " + m + " minutos " + part;
        if (m == 0) text = "Son las " + hour12 + " en punto " + part;
        int status = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "time_announcement");
        if (status == TextToSpeech.ERROR) { speaking = false; player.play(); }
    }

    @Override public MediaSession onGetSession(MediaSession.ControllerInfo info) { return session; }
    @Override public void onDestroy() {
        handler.removeCallbacks(clock);
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (session != null) { session.release(); session = null; }
        if (player != null) player.release();
        super.onDestroy();
    }
}
