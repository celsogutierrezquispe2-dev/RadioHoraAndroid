package com.radiohora.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.MoreExecutors;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 100;
    private ListenableFuture<MediaController> future;
    private MediaController controller;
    private TextView status;
    private final ArrayList<MediaItem> tracks = new ArrayList<>();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 50, 32, 24);
        root.setBackgroundColor(Color.rgb(18, 25, 39));
        TextView title = new TextView(this);
        title.setText("RADIO HORA  •  AUTOMÁTICO"); title.setTextColor(Color.WHITE); title.setTextSize(23);
        title.setGravity(Gravity.CENTER); root.addView(title);
        status = new TextView(this);
        status.setText("Selecciona canciones para comenzar.\nLocución: cada 15 minutos, al terminar la canción.");
        status.setTextColor(Color.LTGRAY); status.setTextSize(16); status.setPadding(0, 30, 0, 30);
        root.addView(status);
        addButton(root, "＋  AGREGAR MÚSICA", () -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("audio/*"); intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(intent, PICK_AUDIO);
        });
        addButton(root, "▶  REPRODUCIR", () -> { if (controller != null) { if (controller.getMediaItemCount() == 0) loadTracks(); controller.play(); } });
        addButton(root, "Ⅱ  PAUSAR", () -> { if (controller != null) controller.pause(); });
        addButton(root, "⏭  SIGUIENTE", () -> { if (controller != null) controller.seekToNextMediaItem(); });
        addButton(root, "⏹  DETENER", () -> { if (controller != null) { controller.pause(); controller.seekTo(0); } });
        setContentView(root);
    }
    private void addButton(LinearLayout parent, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 14;
        parent.addView(b, lp); b.setOnClickListener(v -> action.run());
    }
    @Override protected void onStart() {
        super.onStart();
        SessionToken token = new SessionToken(this, new ComponentName(this, RadioService.class));
        future = new MediaController.Builder(this, token).buildAsync();
        future.addListener(() -> {
            try { controller = future.get(); loadTracks(); }
            catch (Exception e) { Toast.makeText(this, "No se pudo conectar al reproductor", Toast.LENGTH_LONG).show(); }
        }, MoreExecutors.directExecutor());
    }
    private void loadTracks() {
        if (controller == null || tracks.isEmpty()) return;
        controller.setMediaItems(tracks);
        controller.setRepeatMode(Player.REPEAT_MODE_ALL);
        controller.prepare();
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_AUDIO || result != RESULT_OK || data == null) return;
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) addUri(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) addUri(data.getData());
        status.setText(tracks.size() + " canciones cargadas.\nLocución cada 15 minutos, al finalizar la canción.");
        loadTracks();
    }
    private void addUri(Uri uri) {
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (SecurityException ignored) {}
        tracks.add(new MediaItem.Builder().setUri(uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(uri.getLastPathSegment()).build()).build());
    }
    @Override protected void onStop() {
        if (future != null) { MediaController.releaseFuture(future); future = null; controller = null; }
        super.onStop();
    }
}
